//<script src="ui/js/jquery.min.js"></script>

function getURLParameters(sParam)
{
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	var sParameterName;
	for (var i = 0; i < sURLVariables.length; i++)
	{
		sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
			return sParameterName[1];
	}
	return '';
}


if(getURLParameters('page')!='')
	jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/'+getURLParameters('page')+'.html');



function new_fn_navigate_To_OtherPage(newPage,callback_fnc,callback_fn_args,args)
{
	if(!(callback_fn_args==null || callback_fnc==null))
		jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/'+newPage+'.html',function(data){window[callback_fnc](callback_fn_args);});
	else if(callback_fn_args==null && callback_fnc!=null)
		jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/'+newPage+'.html',function(data){window[callback_fnc]();});
	else if(callback_fn_args==null && callback_fnc==null)
		jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/'+newPage+'.html');
}


function fn_navToPage(newPage)
{
	jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/'+newPage+'.html');
}

//////////////////////////////////////////Page Specific Scripts////////////////////////////////////////

function fnct_loadPage1()
{
	fn_navToPage('SIQ-SearchNHID');
	
	var ss_oid = sessionStorage.getItem("oid");
	var ss_nhid = sessionStorage.getItem("nhid");
	var ss_pform = sessionStorage.getItem("pform");
	var ss_tla = sessionStorage.getItem("tla_vs");
	
	//document.getElementById("id_tla").value = ss_tla;
	

}

function fn_trans_page1()
{
	fn_navToPage('SIQ-Prefix_CI_OwnershipChange_Search');

}


function fn_findUserDetails(userIDParam)
{
	
	jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/SIQ-SearchNHID_UserDetails.html');
	sessionStorage.setItem("userIDtoShowDetails", userIDParam);
}

function modifyUserAcnt(){
	fn_navToPage('SIQ-RemoveAccess_Submit');
	
}

function chOwnership()
{
	var selected = new Array();
	var Requestees = new Array();
	var owners = new Array();
	sessionStorage.setItem("newCIOw", "");
	sessionStorage.setItem("oldCiOwner", "");
	sessionStorage.setItem("checkValue", "");

		sessionStorage.setItem("uniqueCiVal", "");
		//Reference the Table.
        var tblCI = document.getElementById("trans_table-body");
 
        //Reference all the CheckBoxes in Table.
        var chks = tblCI.getElementsByTagName("input");
 
        // Loop and push the checked CheckBox value in Array.
        for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
				
				var toTrim = chks[i].value;
				var res = toTrim.split("-");
				Requestees.push(res[0]);
                selected.push(res[1]);
				owners.push(res[2]);
            }
        }
		
		
	var uniqueArray = [];
	
	       // Loop through array values
        for(i=0; i < selected.length; i++){
            if(uniqueArray.indexOf(selected[i]) === -1) {
                uniqueArray.push(selected[i]);
				
            }
        }
    
	sessionStorage.setItem("Requestees_OwnTrans", Requestees.toString());
	
	if(uniqueArray.length==1){
		sessionStorage.setItem("uniqueCiVal", uniqueArray[0]);
		sessionStorage.setItem("oldCiOwner", owners[0]);
		
		jQuery('#pageContainer').load('/identityiq/plugin/NHIDManagement/ui/pages/SIQ-Prefix_CI_OwnershipChange_Submit.html');
		console.log("printing requestees"+sessionStorage.getItem("Requestees_OwnTrans"));
		
	}else{
					var msg = document.getElementById("validationMsg");
					msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
					document.getElementById("validationMsg").innerHTML = "*Please select users having unique/same CI";
	}

}

function clickModify()
{
 var tblCI = document.getElementById("mod_table-body");
 var chks = tblCI.getElementsByTagName("input");	
 var count = 0;
	for (var i = 0; i < chks.length; i++) {
            if (chks[i].checked) {
			count = count+1	
			}
    }
 
if (count == 1) {
fn_navToPage('SIQ-NHID-ModifyRequestPage');
}else if(count > 1){
	var msg = document.getElementById("validationMsg");
	msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
	document.getElementById("validationMsg").innerHTML = "*Only one user can be selected";
	
}else{
	var msg = document.getElementById("validationMsg");
	msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
	document.getElementById("validationMsg").innerHTML = "*Please select One user";
	
}
}

function fn_Trans_Sub()
{
		var tla = sessionStorage.getItem("tla_vs");
		var cival = sessionStorage.getItem("uniqueCiVal");
		var curciowner = sessionStorage.getItem("oldCiOwner");
		
		
		document.getElementById("ci_TransReq").innerHTML = cival;
		document.getElementById("pref_TransReq").innerHTML = tla;
		document.getElementById("CurCIOwner").innerHTML = curciowner;

}

function fn_retriveSessionResult(return_args)
{
	var ss_oid = sessionStorage.getItem("oid");
	var ss_nhid = sessionStorage.getItem("nhid");
	var ss_pform = sessionStorage.getItem("pform");
	var ss_tla = sessionStorage.getItem("tla_vs");
	var ss_sendEmail = "No";
	var CurrentLoggedInUser = PluginHelper.getCurrentUsername();
	var argsString = ss_oid + "-" + ss_nhid + "-" + ss_pform + "-" + ss_tla + "-" + ss_sendEmail + "-"+ CurrentLoggedInUser;
	sessionStorage.setItem("finalStringValue", argsString);
	if(return_args=="SearchNHID"){
	fn_navToPage('SIQ-SearchNHID_Result');
	
	}else if(return_args=="ownershipTransfer"){
	fn_navToPage('SIQ-Prefix_CI_OwnershipChange_Result');
	}else if(return_args=="nhidRemoveAccess"){
	fn_navToPage('SIQ-RemoveAccess_Result');
	}
	else if(return_args=="modifyNHIDUser"){
	fn_navToPage('SIQ-ModifyRequest-SearchResults');
	}
	
}

function fn_emailSearchRes(ReqParam)
{
	var ReqestedFrom = ReqParam;
	
	
if(ReqestedFrom=="Search"){
	var ownerid_value = document.getElementById('idowner').value;
	var nhidusername_value = document.getElementById('nhidusername').value;
	var platform_value = document.getElementById('platformid').value;
	var tla_value = document.getElementById('id_tla').value;
	var sendEmail = "Yes";
	var CurrentLoggedInUser = PluginHelper.getCurrentUsername();
	
	if((ownerid_value==""||ownerid_value==null)&&(nhidusername_value==""||nhidusername_value==null)&&(platform_value==""||platform_value==null)&&(tla_value==""||tla_value==null)){
	
	
	var msg = document.getElementById("validationMsg");
    msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
	document.getElementById("validationMsg").innerHTML = " *Please provide atleast one field value";
	
	}else{
	var finalStringValue = ownerid_value + "-" + nhidusername_value + "-" + platform_value + "-" + tla_value + "-" + sendEmail + "-"+ CurrentLoggedInUser;
	sessionStorage.setItem("finalStringValue", finalStringValue);
	console.log("inside search");
	console.log(finalStringValue);
	
	
	if (typeof(Storage) !== "undefined") {
  // Store

  sessionStorage.setItem("oid", ownerid_value);
  sessionStorage.setItem("nhid", nhidusername_value);
  sessionStorage.setItem("pform", platform_value);
  sessionStorage.setItem("tla_vs", tla_value);
	}
	
	
	}
}else if(ReqestedFrom=="Result"){
	
	var ss_oid = sessionStorage.getItem("oid");
	var ss_nhid = sessionStorage.getItem("nhid");
	var ss_pform = sessionStorage.getItem("pform");
	var ss_tla = sessionStorage.getItem("tla_vs");
	var ss_sendEmail = "Yes";
	var CurrentLoggedInUsername = PluginHelper.getCurrentUsername();
	
	var finalStringValue = ss_oid + "-" + ss_nhid + "-" + ss_pform + "-" + ss_tla + "-" + ss_sendEmail + "-"+ CurrentLoggedInUsername;
	
		console.log("inside Result");
	console.log(finalStringValue);
	}
	
	
	console.log("Outside if loop");
	console.log(finalStringValue);
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/searchuirestservice/getIdentityInfo?identity="+finalStringValue, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				var statusCode = jsonData.userList[0];
				if(statusCode=="Success"){
					var msg = document.getElementById("validationMsg");
					msg.setAttribute("style", "color:Green;  font-size:14px; font-weight: bold;");
					document.getElementById("validationMsg").innerHTML = " Email has been sent Successfully";	
					
				}else if(statusCode=="Error"){
					var msg = document.getElementById("validationMsg");
					msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
					document.getElementById("validationMsg").innerHTML = " No valid email address found. Couldn't send Email";
				}
 
			}
		}
	}
	
	
	
}

function fn_testAjax()
{
	console.log("Inside Test Ajax");
	var ownerid_value = document.getElementById('idowner').value;
	var nhidusername_value = document.getElementById('nhidusername').value;
	var platform_value = document.getElementById('platformid').value;
	var tla_value = document.getElementById('id_tla').value;
	var sendEmail = "No";
	//var ReqType = ReqParam;
	var CurrentLoggedInUser = PluginHelper.getCurrentUsername();
	
	var finalStringValue = ownerid_value + "-" + nhidusername_value + "-" + platform_value + "-" + tla_value + "-" + sendEmail + "-"+ CurrentLoggedInUser;
	var restUrl = PluginHelper.getPluginRestUrl('searchuirestservice/getTestData');
	
			    $.ajax({  
			        type: "GET",  
			        url: restUrl,
			        beforeSend: function(xhr){xhr.setRequestHeader('X-XSRF-TOKEN', PluginHelper.getCsrfToken());},
			        data: 
			        { 
			        	tla_value: tla_value 
			        },
			        success: function (data) 
			        {  
			        	console.log(data);
			        }  
			    }); 
}


function fnct_loadPage2(ReqParam)
{
	var ownerid_value = document.getElementById('idowner').value;
	var nhidusername_value = document.getElementById('nhidusername').value;
	var platform_value = document.getElementById('platformid').value;
	var tla_value = document.getElementById('id_tla').value;
	var sendEmail = "No";
	var ReqType = ReqParam;
	var CurrentLoggedInUser = PluginHelper.getCurrentUsername();
if((ownerid_value==""||ownerid_value==null)&&(nhidusername_value==""||nhidusername_value==null)&&(platform_value==""||platform_value==null)&&(tla_value==""||tla_value==null)){
	
	var msg = document.getElementById("validationMsg");
    msg.setAttribute("style", "color:red;  font-size:14px; font-weight: bold;");
	document.getElementById("validationMsg").innerHTML = " *Please provide atleast one field value";
	
	
}else{
	
	if (typeof(Storage) !== "undefined") {
  // Store

  sessionStorage.setItem("oid", ownerid_value);
  sessionStorage.setItem("nhid", nhidusername_value);
  sessionStorage.setItem("pform", platform_value);
  sessionStorage.setItem("tla_vs", tla_value);
  sessionStorage.setItem("sendEmail", "No");
  sessionStorage.setItem("ReqType", ReqParam);
	
	
	var finalStringValue = ownerid_value + "-" + nhidusername_value + "-" + platform_value + "-" + tla_value + "-" + sendEmail + "-"+ CurrentLoggedInUser;
	sessionStorage.setItem("finalStringValue", finalStringValue);
	
	if(ReqParam=="OwnershipChange"){
	fn_navToPage('SIQ-Prefix_CI_OwnershipChange_Result');
	}else if(ReqParam=="searchNHID"){
		fn_navToPage('SIQ-SearchNHID_Result');
		
	}else if(ReqParam=="nhidRemoveAccess"){
		fn_navToPage('SIQ-RemoveAccess_Result');
		
	}else if(ReqParam=="modifyNHID"){
		fn_navToPage('SIQ-ModifyRequest-SearchResults');
	}
	
	}else{
		document.getElementById("validationMsg").innerHTML = " *Error Code: Unsupported Browser";
	}
	
}
}

function checkAllbx(bx) {
  var cbs = document.getElementsByTagName('input');
  for(var i=0; i < cbs.length; i++) {
    if(cbs[i].type == 'checkbox') {
      cbs[i].checked = bx.checked;
    }
  }
}

function fnctn_searchIdentity()

{
	var Rtype = sessionStorage.getItem("ReqType");
	var Rest_String = sessionStorage.getItem("finalStringValue");
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/searchuirestservice/getIdentityInfo?identity="+Rest_String, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				console.log(jsonData.userList[0]);
				console.log(jsonData.userList[1]);
				localStorage.setItem("searchData", JSON.stringify(jsonData));
				var tableValue = jsonData.userList;
				var tableValueLength = tableValue.length;
				console.log(tableValue.length);
				
				
				if(Rtype=="searchNHID"){
				
				$("#searchResTable").find("tr").remove();
				var table = document.getElementById("searchResTable");				
				var header = table.createTHead();
				
				var headerRow = header.insertRow(0);
				var tr = document.getElementById('searchResTable').tHead.children[0];
				
				}else if(Rtype=="OwnershipChange"){
					
				$("#trans_searchResTable").find("tr").remove();
				var table = document.getElementById("trans_searchResTable");				
				var header = table.createTHead();
				if(tableValue.length > 0){
					sessionStorage.setItem("tla_vs", tableValue[0].tla);
				}
				var headerRow = header.insertRow(0);
				var tr = document.getElementById('trans_searchResTable').tHead.children[0];
				var str = '<td>'+'<input type="checkbox" onclick="checkAllbx(this)">'+'</input>'+'</td>';	
					th3 = document.createElement('th');
					th3.innerHTML = str;
					tr.appendChild(th3);
					
				}else if(Rtype=="nhidRemoveAccess"){
					
				$("#NewMod_searchResTable").find("tr").remove();
				var table = document.getElementById("NewMod_searchResTable");				
				var header = table.createTHead();
				if(tableValue.length > 0){
					sessionStorage.setItem("tla_vs", tableValue[0].tla);
				}
				var headerRow = header.insertRow(0);
				var tr = document.getElementById('NewMod_searchResTable').tHead.children[0];
				var str = '<td>'+'<input type="checkbox" onclick="checkAllbx(this)">'+'</input>'+'</td>';	
					th3 = document.createElement('th');
					th3.innerHTML = str;
					tr.appendChild(th3);
					
				}else if(Rtype=="modifyNHID"){
					
				$("#mod_searchResTable").find("tr").remove();
				var table = document.getElementById("mod_searchResTable");				
				var header = table.createTHead();
				
				var headerRow = header.insertRow(0);
				var tr = document.getElementById('mod_searchResTable').tHead.children[0];
					th3 = document.createElement('th');
					th3.innerHTML = "";
					tr.appendChild(th3);
				}
				
				
			    th1 = document.createElement('th');
				th1.innerHTML = "User ID";
				//th1.setAttribute('style',"color:white");
				tr.appendChild(th1);
				
				th4 = document.createElement('th');
				th4.innerHTML = "CI";
				//th4.setAttribute('style',"color:white");
				tr.appendChild(th4);
				
				th5 = document.createElement('th');
				th5.innerHTML = "Prefix";
				//th5.setAttribute('style',"color:white");
				tr.appendChild(th5);
				
				th6 = document.createElement('th');
				th6.innerHTML = "Platform";
				//th6.setAttribute('style',"color:white");
				tr.appendChild(th6);
				
				th7 = document.createElement('th');
				th7.innerHTML = "Owner ID";
				//th7.setAttribute('style',"color:white");
				tr.appendChild(th7);
				
				th8 = document.createElement('th');
				th8.innerHTML = "Environment";
				//th8.setAttribute('style',"color:white");
				tr.appendChild(th8);
				
				th2 = document.createElement('th');
				th2.innerHTML = "Type ID";
				//th2.setAttribute('style',"color:white");
				tr.appendChild(th2);
				
				if(Rtype=="nhidRemoveAccess"){
				th9 = document.createElement('th');
				th9.innerHTML = "Last Used Date";
				//th9.setAttribute('style',"color:white");
				tr.appendChild(th9);
				}

				if(Rtype=="searchNHID"){
				   
				//var tablebdy = $('#table-body')

				for (var i = 0; i < tableValueLength; i++) 
					{
					var rowValues = tableValue[i];
					var rowValuesLength = rowValues.length;
					
					
					  var row = $("<tr>");
	 $('<td></td>').text("").prepend($('<a></a>').attr({ href: "javascript:fn_findUserDetails("+"'"+rowValues.userId+"'"+")" }).text(rowValues.userId)).appendTo(row);
     row.append($("<td>"+rowValues.ci+"</td>"))
     .append($("<td>"+rowValues.tla+"</td>"))
     .append($("<td>"+rowValues.platform+"</td>"))
     .append($("<td>"+rowValues.managerEmployeeId+"</td>"))
     .append($("<td>"+rowValues.environment+"</td>"))
     .append($("<td>"+rowValues.nhidAccountType+"</td>"));
	 
 
  $("#table-body").append(row);
					}

				$(document).ready( function () {
				$('#searchResTable').DataTable();
				} );
				
				}else if(Rtype=="OwnershipChange"){
				var tablebdy = $('#trans_table-body')

				for (var i = 0; i < tableValueLength; i++) 
					{
					var rowValues = tableValue[i];
		
					var rowValuesLength = rowValues.length;
					
					
					  var row = $("<tr>");
	$('<td></td>').text("").prepend($('<input type="checkbox"></input>').attr({ id : rowValues.userId, value:rowValues.userId+"-"+rowValues.ci+"-"+rowValues.managerEmployeeId}).text("")).appendTo(row);
	row.append($("<td>"+rowValues.userId+"</td>"))
     .append($("<td>"+rowValues.ci+"</td>"))
     .append($("<td>"+rowValues.tla+"</td>"))
     .append($("<td>"+rowValues.platform+"</td>"))
     .append($("<td>"+rowValues.managerEmployeeId+"</td>"))
     .append($("<td>"+rowValues.environment+"</td>"))
     .append($("<td>"+rowValues.nhidAccountType+"</td>"));
	 
 
  $("#trans_table-body").append(row);
					}

				$(document).ready( function () {
				$('#trans_searchResTable').DataTable();
				} );
				
				
				}else if(Rtype=="nhidRemoveAccess"){
				var tablebdy = $('#NewModTabbody')

				for (var i = 0; i < tableValueLength; i++) 
					{
					var rowValues = tableValue[i];
		
					var rowValuesLength = rowValues.length;
					
					
					  var row = $("<tr>");
	$('<td></td>').text("").prepend($('<input type="checkbox"></input>').attr({ id : rowValues.userId, value:rowValues.userId+"-"+rowValues.ci+"-"+rowValues.managerEmployeeId}).text("")).appendTo(row);
	row.append($("<td>"+rowValues.userId+"</td>"))
     .append($("<td>"+rowValues.ci+"</td>"))
     .append($("<td>"+rowValues.tla+"</td>"))
     .append($("<td>"+rowValues.platform+"</td>"))
     .append($("<td>"+rowValues.managerEmployeeId+"</td>"))
     .append($("<td>"+rowValues.environment+"</td>"))
     .append($("<td>"+rowValues.nhidAccountType+"</td>"))
	 .append($("<td>Not Available</td>"));
 
  $("#NewModTabbody").append(row);
					}

				$(document).ready( function () {
				$('#NewMod_searchResTable').DataTable();
				} );
				
				
				}else if(Rtype=="modifyNHID"){
					
				var tablebdy = $('#mod_table-body')

				for (var i = 0; i < tableValueLength; i++) 
					{
					var rowValues = tableValue[i];
		
					var rowValuesLength = rowValues.length;
					var row = $("<tr>");
  $('<td></td>').text("").prepend($('<input type="checkbox" class="search_list"></input>').attr({ id : "All", onclick: "selectedUser("+"'"+rowValues.userId+"'"+")" }).text("")).appendTo(row);	
  /*<script type="text/javascript">
					$('.search_list').on('change', function() {
					$('.search_list').not(this).prop('checked', false);  
					});
					</script>
					*/
  row.append($("<td>"+rowValues.userId+"</td>"))
     .append($("<td>"+rowValues.ci+"</td>"))
     .append($("<td>"+rowValues.tla+"</td>"))
     .append($("<td>"+rowValues.platform+"</td>"))
     .append($("<td>"+rowValues.managerEmployeeId+"</td>"))
     .append($("<td>"+rowValues.environment+"</td>"))
     .append($("<td>"+rowValues.nhidAccountType+"</td>"));
	 
 
  $("#mod_table-body").append(row);
					
					}
				$(document).ready( function () {
				$('#mod_searchResTable').DataTable();
				} );
				
				
				}

 
			}
		}
	}
}




function fn_showDetails(user)
{
	var userIDParam = sessionStorage.getItem("userIDtoShowDetails");
	console.log('Displaying User ID Parameterm in final get function-');
	console.log(userIDParam);
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/userdetailsRestService/getUserInfo?nhidUserID="+userIDParam, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				
				console.log(jsonData.userList[0]);
				console.log(jsonData.userList[1]);
				
				var tableValue = jsonData.userList;
				var tableValueLength = tableValue.length;
				console.log(tableValue.length);
				$("#userDataTable").find("tr").remove();
				var table = document.getElementById("userDataTable");
				
				var header = table.createTHead();
				
		var node = document.createTextNode("User Details : "+userIDParam);
		var headreidele = document.getElementById("headerid");
		headreidele.appendChild(node);
		
		
    var tablebdynew = $('#Usertable-body')

	for (var i = 0; i < tableValueLength; i++) 
    {
    	var rowValues = tableValue[i];
		var row = $("<tr>");
		var row1 = $("<tr>");
		var row2 = $("<tr>");
		var row3 = $("<tr>");
		var row4 = $("<tr>");
		var row5 = $("<tr>");
		var row6 = $("<tr>");
		var row7 = $("<tr>");
		var row8 = $("<tr>");
		var row9 = $("<tr>");
		var row10 = $("<tr>");
		var row11 = $("<tr>");
		var row12 = $("<tr>");
		var row13 = $("<tr>");
		var row14 = $("<tr>");
		var row15 = $("<tr>");
		var row16 = $("<tr>");
		var row17 = $("<tr>");
		var row18 = $("<tr>");
		var row19 = $("<tr>");
		var row20 = $("<tr>");
		var row21 = $("<tr>");
		var row22 = $("<tr>");
		var row23 = $("<tr>");
		var row24 = $("<tr>");
		var row25 = $("<tr>");
row.append($("<td class='attributeTitleColumn'><b>User ID</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.user_ID+"</td>"))

row1.append($("<td class='attributeTitleColumn'><b>Employee Number</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.employee_Number+"</td>"))

row2.append($("<td class='attributeTitleColumn'><b>Account type</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.account_Type+"</td>"))

row3.append($("<td class='attributeTitleColumn'><b>Type ID</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.id_type+"</td>"))

row4.append($("<td class='attributeTitleColumn'><b>Platform</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.platform+"</td>"))

row5.append($("<td class='attributeTitleColumn'><b>Environment</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.environment+"</td>"))

row6.append($("<td class='attributeTitleColumn'><b>Is Manager</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.manager_status+"</td>"))

row7.append($("<td class='attributeTitleColumn'><b>Job Title</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.job_Title+"</td>"))

row8.append($("<td class='attributeTitleColumn'><b>Company</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.company+"</td>"))

row9.append($("<td class='attributeTitleColumn'><b>Company Name</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.company_Name+"</td>"))

row10.append($("<td class='attributeTitleColumn'><b>Cost Centre</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.cost_Center+"</td>"))

row11.append($("<td class='attributeTitleColumn'><b>Cost Centre Name</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.cost_Center_Name+"</td>"))

row12.append($("<td class='attributeTitleColumn'><b>Department ID</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.department_ID+"</td>"))

row13.append($("<td class='attributeTitleColumn'><b>Work Phone</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.phone_Number+"</td>"))

row14.append($("<td class='attributeTitleColumn'><b>Mail Code</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.mail_code+"</td>"))

row15.append($("<td class='attributeTitleColumn'><b>Officer Code</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.officer_code+"</td>"))

row16.append($("<td class='attributeTitleColumn'><b>Email</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.email_Address+"</td>"))

row17.append($("<td class='attributeTitleColumn'><b>Prefix</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.prefix+"</td>"))

row18.append($("<td class='attributeTitleColumn'><b>CI</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ci+"</td>"))

row19.append($("<td class='attributeTitleColumn'><b>Owner ID</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ownerID+"</td>"))

row20.append($("<td class='attributeTitleColumn'><b>CI Owner Cost Centre</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ciowner_Cost_Center+"</td>"))

row21.append($("<td class='attributeTitleColumn'><b>CI Owner Cost Centre Name</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ciowner_Cost_Center_Name+"</td>"))

row22.append($("<td class='attributeTitleColumn'><b>CI Owner Phone</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ciowner_Phone+"</td>"))

row23.append($("<td class='attributeTitleColumn'><b>CI Owner Email</b></td>"))
     .append($("<td class='attributeValueColumn'>"+rowValues.ciowner_Email+"</td>"))


$("#Usertable-body").append(row);
$("#Usertable-body").append(row1);
$("#Usertable-body").append(row2);
$("#Usertable-body").append(row3);
$("#Usertable-body").append(row4);
$("#Usertable-body").append(row5);
$("#Usertable-body").append(row6);
$("#Usertable-body").append(row7);
$("#Usertable-body").append(row8);
$("#Usertable-body").append(row9);
$("#Usertable-body").append(row10);
$("#Usertable-body").append(row11);
$("#Usertable-body").append(row12);
$("#Usertable-body").append(row13);
$("#Usertable-body").append(row14);
$("#Usertable-body").append(row15);
$("#Usertable-body").append(row16);
$("#Usertable-body").append(row17);
$("#Usertable-body").append(row18);
$("#Usertable-body").append(row19);
$("#Usertable-body").append(row20);
$("#Usertable-body").append(row21);
$("#Usertable-body").append(row22);
$("#Usertable-body").append(row23);

}



				
			}
		}
	}
}


//Generate Excel Sheet

function JSONToCSVConvertor() {
    //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
    var list = JSON.parse(localStorage.getItem("searchData"));
	var arrData = list.userList;
   console.log("Into JSONToCSVConvertor function");
   console.log(arrData);
	
    var CSV = '';    
    //Set Report title in first row or line
    var ReportTitle = "NHID";
    //CSV += ReportTitle + '\r\n\n';
	var ShowLabel = true;
    //This condition will generate the Label/Header
    if (ShowLabel) {
        var row = "";
        
        //This loop will extract the label from 1st index of on array
        for (var index in arrData[0]) {
            
            //Now convert each value to string and comma-seprated
            row += index + ',';
        }
		var headerRow = "CI,Environment,Owner ID,Type ID,Platform,Prefix,User ID,";
        row = headerRow.slice(0, -1);
        
        //append Label row with line break
        CSV += row + '\r\n';
    }
    
    //1st loop is to extract each row
    for (var i = 0; i < arrData.length; i++) {
        var row = "";
        
        //2nd loop will extract each column and convert it in string comma-seprated
        for (var index in arrData[i]) {
            row += '"' + arrData[i][index] + '",';
        }

        row.slice(0, row.length - 1);
        
        //add a line break after each row
        CSV += row + '\r\n';
    }

    if (CSV == '') {        
        alert("Invalid data");
        return;
    }   
    
    //Generate a file name
    var fileName = "NHIDSearchResult";
    //this will remove the blank-spaces from the title and replace it with an underscore
    //fileName += ReportTitle.replace(/ /g,"_");   
    
    //Initialize file format you want csv or xls
    var uri = 'data:text/csv;charset=utf-8,' + escape(CSV);
    
    // Now the little tricky part.
    // you can use either>> window.open(uri);
    // but this will not work in some browsers
    // or you will not get the correct file extension    
    
    //this trick will generate a temp <a /> tag
    var link = document.createElement("a");    
    link.href = uri;
    
    //set the visibility hidden so it will not effect on your web-layout
    link.style = "visibility:hidden";
    link.download = fileName + ".csv";
    
    //this part will append the anchor tag and remove it after automatic click
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

function fn_subRequest(){
	
	var oldci= sessionStorage.getItem("uniqueCiVal");
	var oldPref =sessionStorage.getItem("tla_vs");
	var oldciowner = sessionStorage.getItem("oldCiOwner");
	var newCI=sessionStorage.getItem("checkValue");
	//var newTLA = document.getElementById("prefix").value;
	var newTLA= sessionStorage.getItem("newPefixEntered");
	var newCIOwner= sessionStorage.getItem("newCIOw");
	var reqts = sessionStorage.getItem("Requestees_OwnTrans");
	var LoggedInusername = PluginHelper.getCurrentUsername();
	var Rest_String= oldci+","+oldPref+","+oldciowner+","+newCI+","+newTLA+","+newCIOwner+","+LoggedInusername+"-"+reqts;
	
console.log(Rest_String);
	
	
	if((oldci==newCI)&&(oldciowner==newCIOwner)){
		document.getElementById("valid_ci_pre").innerHTML = "*Selected CI is same as old with same CI Owner. Please select appropriate new CI";
		
	}else if((newTLA==""||newTLA==null)||(newCI==""||newCI==null)){
		
		document.getElementById("valid_ci_pre").innerHTML = "*Please select valid Prefix and CI";
		
	}else{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/searchuirestservice/launchWorkFlow?SubmitPara="+Rest_String, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				if(jsonData=="Success"){
					sessionStorage.setItem("OwnertransferReqStatus", "Success")
				}else{
					sessionStorage.setItem("OwnertransferReqStatus", "Fail")
				}
				fn_navToPage('SIQ-ReqStatusPage');
 
			}
		}
	}
	
	}
	
	
}

function selectedUser(selectuser)
{
	var oldci= sessionStorage.setItem("uiselectuser",selectuser);
}


function fn_modify_subRequest()
{
       var prefix_mod_value = document.getElementById("prefix_modify").value;
       var domain_mod_value = document.getElementById("domain_modify").value;
       var servername_mod_value = document.getElementById("servername_modify").value;
       var localgroup_mod_value = document.getElementById("localgroup_modify").value;
       var activedirectory_mod_value = document.getElementById("activedirectory_modify").value;
	   var requested_mod_value = sessionStorage.getItem("uiselectuser");
       var businessjustification_mod_value = document.getElementById("businessjustification_modify").value;
       var adminaccess_production_modval = document.getElementById("adminaccess_production").value;
	   var LoggedInusername_modify = PluginHelper.getCurrentUsername();
	   
	   
	   
	   if((prefix_mod_value==""||prefix_mod_value==null)||(domain_mod_value==""||domain_mod_value==null)||(servername_mod_value==""||servername_mod_value==null)||(businessjustification_mod_value==""||businessjustification_mod_value==null)||(adminaccess_production_modval==""||adminaccess_production_modval==null)){
			document.getElementById("valid_modifyFields").innerHTML = " *Please provide Mandatory fields";
			
	   }
	   
	   else{
	  var modifyrequestobj = prefix_mod_value+"@"+domain_mod_value+"@"+servername_mod_value+"@"+localgroup_mod_value+"@"+activedirectory_mod_value+"@"+businessjustification_mod_value+"@"+adminaccess_production_modval+"@"+requested_mod_value+"@"+LoggedInusername_modify;
	   console.log("Printing rest String :"+modifyrequestobj);
       xhttp = new XMLHttpRequest();
       xhttp.open("POST", "/identityiq/plugin/rest/searchuirestservice/getSubmitDataFromModify?modifyrequestobj="+modifyrequestobj, true);
       xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
       xhttp.setRequestHeader('Content-Type', 'application/json');
       xhttp.send();
       console.log("successd");
       xhttp.onreadystatechange = function()
       {
              if(this.readyState == 4)
              {
                     if (this.status == 200)
                     {
                           var txt=this.responseText;
                           var jsonData = JSON.parse(txt);
                           console.log(jsonData);
						   if(jsonData=="Success"){
							sessionStorage.setItem("ModifyNHIDReqStatus", "Success")
							}else{
							sessionStorage.setItem("ModifyNHIDReqStatus", "Fail")
							}
							fn_navToPage('SIQ-ModifyReqStatusPage');
                           

                     }
              }
       }
       
}
}



function fn_modify_loadDomains() {
console.log("Inside fn_loadDomains Function Modify");


  //var platform = document.getElementById("environment").value;

  xhttp = new XMLHttpRequest();
xhttp.open("POST", "/identityiq/plugin/rest/nhidcreaterestapi/getDomainInfo", true);
xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
xhttp.setRequestHeader('Content-Type', 'application/json');
xhttp.send();
console.log("request sent to webservice api.");

xhttp.onreadystatechange = function()
{
if(this.readyState == 4)
{
if (this.status == 200)
{
var txt=this.responseText;
var jsonData = JSON.parse(txt);
//var obj = JSON.parse(jsonData);
console.log("Data received.");
document.getElementById("domain_modify").innerHTML = "";
var ele = document.getElementById('domain_modify');
ele.innerHTML = ele.innerHTML + '<option value="" disabled selected>-- Select Domain --</option>';
var index;
console.log(jsonData);
for (index = 0; index < jsonData.domainList.length; index++) {

console.log(jsonData.domainList[index]);
ele.innerHTML = ele.innerHTML + '<option value="' + jsonData.domainList[index] + '">'+jsonData.domainList[index]+'</option>';

}



}


}
}


}

function fn_modify_loadADGroups() {
console.log("Inside fn_modify_loadADGroups Function ");


  //var platform = document.getElementById("environment").value;

  xhttp = new XMLHttpRequest();
xhttp.open("POST", "/identityiq/plugin/rest/nhidcreaterestapi/getADGroups", true);
xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
xhttp.setRequestHeader('Content-Type', 'application/json');
xhttp.send();
console.log("request sent to webservice api.");

                    xhttp.onreadystatechange = function()
                   {
                    if(this.readyState == 4)
                         {
                           if (this.status == 200)
							{
                                   var txt=this.responseText;
                                    var jsonData = JSON.parse(txt);
                                     //var obj = JSON.parse(jsonData);
                                        console.log("Data received.");
										
										var index;
										var arr = new Array();
										for (index = 0; index < jsonData.activeDirectoryGroups.length; index++) {
											arr.push(jsonData.activeDirectoryGroups[index])
										}
											$( function() {


											$( "#activedirectory_modify" ).autocomplete({
											source: arr
											});
											});
                              /*     document.getElementById("activedirectory_modify").innerHTML = "";
                                  var ele = document.getElementById('activedirectory_modify');
                                    ele.innerHTML = ele.innerHTML + '<option value="" selected>-- Select AD Group --</option>';
                                       var index;
                                   console.log(jsonData);
                                  for (index = 0; index < jsonData.activeDirectoryGroups.length; index++) {
                                           console.log(jsonData.activeDirectoryGroups[index]);
                                           ele.innerHTML = ele.innerHTML + '<option value="' + jsonData.activeDirectoryGroups[index] + '">'+jsonData.activeDirectoryGroups[index]+'</option>';
                                            }*/

                                  }


                          }
           }

}



function fn_modify_loadLoadServerName() {
console.log("Inside fn_modify_loadADGroups Function ");


  //var platform = document.getElementById("environment").value;

  xhttp = new XMLHttpRequest();
xhttp.open("POST", "/identityiq/plugin/rest/nhidcreaterestapi/getLocalServers", true);
xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
xhttp.setRequestHeader('Content-Type', 'application/json');
xhttp.send();
console.log("request sent to webservice api.");

                    xhttp.onreadystatechange = function()
                     {
                      if(this.readyState == 4)
                       {
                             if (this.status == 200)
                                {
                                   var txt=this.responseText;
                                   var jsonData = JSON.parse(txt);
                                    document.getElementById("servername_modify").innerHTML = "";
                                    var ele = document.getElementById('servername_modify');
                                    ele.innerHTML = ele.innerHTML + '<option value="" selected>-- Select Local Server --</option>';
                                    var index;
                                     console.log(jsonData);
                                   for (index = 0; index < jsonData.localServerNames.length; index++) {
                                       console.log(jsonData.localServerNames[index]);
                                       ele.innerHTML = ele.innerHTML + '<option value="' + jsonData.localServerNames[index] + '">'+jsonData.localServerNames[index]+'</option>';
                                        }

                              }


                    }
            }

}



function fn_modify_page1()
{
	fn_navToPage('SIQ-ModifyRequest-SearchPage');
}
function fn_modify_page3()
{
	fn_navToPage('SIQ-NHID-ModifyRequestPage');
}


/*
function fn_getTLAData()
{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "/identityiq/plugin/rest/userdetailsRestService/getPrefixList", true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				console.log("One");
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				
				
				
	var selected = new Array();
	
        for (var i = 0; i < jsonData.length; i++) {
                selected.push(jsonData[i]);
            
        }
		console.log("Selected Array Length"+selected.length);	
		
	var uniqueArray = [];
	
	       // Loop through array values
        for(i=0; i < selected.length; i++){
            if(uniqueArray.indexOf(selected[i]) === -1) {
                uniqueArray.push(selected[i]);
				
            }
        }
				$( "#tags" ).autocomplete({
				source: uniqueArray;
				});	
		console.log("Unique array lenghth"+uniqueArray.length);		
				
				
				
			}
		}
	}
}

*/


function preventFieldCharactersModify()
{
	document.getElementById('prefix_modify').onkeypress =
  function (e) {
	if (e.which < 48 || 
    (e.which > 57 && e.which < 65) || 
    (e.which > 90 && e.which < 97) ||
    e.which > 122) {
    e.preventDefault();
}
}
	document.getElementById('servername_modify').onkeypress =
  function (e) {
	if (e.which < 48 || 
    (e.which > 57 && e.which < 65) || 
    (e.which > 90 && e.which < 97) ||
    e.which > 122) {
    e.preventDefault();
}
}
document.getElementById('localgroup_modify').onkeypress =
  function (e) {
	if (e.which < 48 || 
    (e.which > 57 && e.which < 65) || 
    (e.which > 90 && e.which < 97) ||
    e.which > 122) {
    e.preventDefault();
}
}
/*document.getElementById('businessjustification_modify').onkeypress =
  function (e) {
	if (e.which < 48 || 
    (e.which > 57 && e.which < 65) || 
    (e.which > 90 && e.which < 97) ||
    e.which > 122) {
    e.preventDefault();
}
}*/
}
function restrictPasteSpecialCharsModify()
{
	$(function(){

   $( "#prefix_modify" ).bind( 'paste',function()
   {
       setTimeout(function()
       { 
          //get the value of the input text
          var data= $( '#prefix_modify' ).val() ;
          //replace the special characters to '' 
          var dataFull = data.replace(/[^\w\s]/gi, '');
          //set the new value of the input text without special characters
          $( '#prefix_modify' ).val(dataFull);
       });

    });
});
$(function(){

   $( "#servername_modify" ).bind( 'paste',function()
   {
       setTimeout(function()
       { 
          //get the value of the input text
          var data= $( '#servername_modify' ).val() ;
          //replace the special characters to '' 
          var dataFull = data.replace(/[^\w\s]/gi, '');
          //set the new value of the input text without special characters
          $( '#servername_modify' ).val(dataFull);
       });

    });
});
$(function(){

   $( "#localgroup_modify" ).bind( 'paste',function()
   {
       setTimeout(function()
       { 
          //get the value of the input text
          var data= $( '#localgroup_modify' ).val() ;
          //replace the special characters to '' 
          var dataFull = data.replace(/[^\w\s]/gi, '');
          //set the new value of the input text without special characters
          $( '#localgroup_modify' ).val(dataFull);
       });

    });
});
/*$(function(){

   $( "#businessjustification_modify" ).bind( 'paste',function()
   {
       setTimeout(function()
       { 
          //get the value of the input text
          var data= $( '#businessjustification_modify' ).val() ;
          //replace the special characters to '' 
          var dataFull = data.replace(/[^\w\s]/gi, '');
          //set the new value of the input text without special characters
          $( '#businessjustification_modify' ).val(dataFull);
       });

    });
});*/
}