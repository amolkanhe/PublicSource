//<script src="ui/js/jquery.min.js"></script>
function getURLParameters(sParam)
{
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	var sParameterName;
	for (var i = 0; i < sURLVariables.length; i++)
	{
		sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam)
			return sParameterName[1];
	}
	return '';
}

if(getURLParameters('page')!='')
	jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+getURLParameters('page')+'.html');

function new_fn_navigate_To_OtherPage(newPage,callback_fnc,callback_fn_args)
{
	if(!(callback_fn_args==null || callback_fnc==null))
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fnc](callback_fn_args);});
	else if(callback_fn_args==null && callback_fnc!=null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html',function(data){window[callback_fnc]();});
	else if(callback_fn_args==null && callback_fnc==null)
		jQuery('#pageContainer').load('/identityiq/plugin/testui/ui/pages/'+newPage+'.html');
}

//////////////////////////////////////////Page Specific Scripts////////////////////////////////////////

function fnct_loadPage1()
{
	new_fn_navigate_To_OtherPage('pagex',null,null);
}

//==================

$(document).ready(function() {
    $('#searchResTable').DataTable( {
        "pagingType": "full_numbers"
    } );
} );


//========================

function fnct_loadPage2()
{
	var ownerid_value = document.getElementById('idowner').value;
	var nhidusername_value = document.getElementById('nhidusername').value;
	var platform_value = document.getElementById('platformid').value;
	var tla_value = document.getElementById('id_tla').value;
	var workerType = document.getElementById('wtype').value;
	
	var finalStringValue = ownerid_value + "-" + nhidusername_value + "-" + platform_value + "-" + tla_value + "-" + workerType
	
	//var finalStringValue = workerType;
	new_fn_navigate_To_OtherPage('pagey','fnctn_searchIdentity',finalStringValue);
	//fnctn_searchIdentity(finalStringValue);
	
}

function fn_findUserDetails(userIDParam)
{
	new_fn_navigate_To_OtherPage('pagez','fn_showDetails',userIDParam);
	
}

function fn_showDetails(userIDParam)
{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "https://sdc01siqptta02x.keybank.com:8443/identityiq/plugin/rest/userdetailsRestService/getUserInfo?nhidUserID="+userIDParam, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				
				console.log(jsonData.userList[0]);
				console.log(jsonData.userList[1]);
				console.log(jsonData.userList[2]);
				
				
				console.log(jsonData.userList[1].firstname);
				//document.getElementById('fnval').value=jsonData.firstName;
				//document.getElementById('lnval').value=jsonData.lastName;
				
				var tableValue = jsonData.userList;
				var tableValueLength = tableValue.length;
				console.log(tableValue.length);
				var table = document.getElementById("userDataTable");
				//var tableHead = document.getElementById('userDataTable').getElementsByTagName('thead')[0];
				var tableBody = document.getElementById('userDataTable').getElementsByTagName('tbody')[0];
				
				var header = table.createTHead();
				
				
		
    var tablebdynew = $('#Usertable-body')

	for (var i = 0; i < tableValueLength; i++) 
    {
    	//var row = tableBody.insertRow(i);
    	var rowValues = tableValue[i];
		
    	var rowValuesLength = rowValues.length;
        //Keep in mind we are using "Template Litterals to create rows"
        var nrow = `<tr>
                  <td><b>User ID</b></td>
                  <td>${rowValues.user_id}</td>
				  <tr>
                  <td><b>Employee Number</b></td>
                  <td>${rowValues.employee_Number}</td>
				  <tr>
                  <td><b>Employee Number</b></td>
                  <td>${rowValues.account_Type;}</td>
				  <tr>
                  <td><b>Employee Number</b></td>
                  <td>${rowValues.id_type;}</td>
				  <tr>
                  `
        tablebdynew.append(nrow)
					
	
}

function fnctn_searchIdentity(finalStringValue)

{
	xhttp = new XMLHttpRequest();
	xhttp.open("POST", "https://sdc01siqptta02x.keybank.com:8443/identityiq/plugin/rest/searchuirestservice/getIdentityInfo?identity="+finalStringValue, true);
	xhttp.setRequestHeader("X-XSRF-TOKEN", Ext.util.Cookies.get('CSRF-TOKEN'));
	xhttp.setRequestHeader('Content-Type', 'application/json');
	xhttp.send();
	
	xhttp.onreadystatechange = function()
	{
		if(this.readyState == 4)
		{
			if (this.status == 200)
			{
				var txt=this.responseText;
				var jsonData = JSON.parse(txt);
				console.log(jsonData);
				
				console.log(jsonData.userList[0]);
				console.log(jsonData.userList[1]);
				console.log(jsonData.userList[2]);
				
				
				console.log(jsonData.userList[1].firstname);
				//document.getElementById('fnval').value=jsonData.firstName;
				//document.getElementById('lnval').value=jsonData.lastName;
				
				var tableValue = jsonData.userList;
				var tableValueLength = tableValue.length;
				console.log(tableValue.length);
				var table = document.getElementById("searchResTable");
				//var tableHead = document.getElementById('searchResTable').getElementsByTagName('thead')[0];
				var tableBody = document.getElementById('searchResTable').getElementsByTagName('tbody')[0];
				
				var header = table.createTHead();
				
				var headerRow = header.insertRow(0);
				var tr = document.getElementById('searchResTable').tHead.children[0],
			    th1 = document.createElement('th');
				th1.innerHTML = "User ID";
				tr.appendChild(th1);
				
				th2 = document.createElement('th');
				th2.innerHTML = "First Name";
				tr.appendChild(th2);
				
				th3 = document.createElement('th');
				th3.innerHTML = "Last Name";
				tr.appendChild(th3);
				
				th4 = document.createElement('th');
				th4.innerHTML = "CI";
				tr.appendChild(th4);
				
				th5 = document.createElement('th');
				th5.innerHTML = "TLA";
				tr.appendChild(th5);
				
				th6 = document.createElement('th');
				th6.innerHTML = "Platform";
				tr.appendChild(th6);
				
				th7 = document.createElement('th');
				th7.innerHTML = "Owner ID";
				tr.appendChild(th7);
				
				th8 = document.createElement('th');
				th8.innerHTML = "Environment";
				tr.appendChild(th8);
				
				
				

	/*			
				
				var headerCell1 = headerRow.insertCell(0);
				var headerCell2 = headerRow.insertCell(1);
				var headerCell3 = headerRow.insertCell(2);
				var headerCell4 = headerRow.insertCell(3);
				var headerCell5 = headerRow.insertCell(4);
				var headerCell6 = headerRow.insertCell(5);
				var headerCell7 = headerRow.insertCell(6);
				var headerCell8 = headerRow.insertCell(7);
				
				
		
	
				headerCell1.innerHTML = "<b>User ID</b>";
				headerCell2.innerHTML = "<b>First Name</b>";
				headerCell3.innerHTML = "<b>Last Name</b>";
				headerCell4.innerHTML = "<b>CI</b>";
				headerCell5.innerHTML = "<b>TLA</b>";
				headerCell6.innerHTML = "<b>Platform</b>";
				headerCell7.innerHTML = "<b>Owner ID</b>";
				headerCell8.innerHTML = "<b>Environment</b>";	

*/


    var tablebdy = $('#table-body')

	for (var i = 0; i < tableValueLength; i++) 
    {
    	//var row = tableBody.insertRow(i);
    	var rowValues = tableValue[i];
		
    	var rowValuesLength = rowValues.length;
        //Keep in mind we are using "Template Litterals to create rows"
        var newrow = `<tr>
                  <td><a id="getUserDetailsLink" onclick="fn_findUserDetails('${rowValues.userId}');">${rowValues.userId}</a></td>
                  <td>${rowValues.firstname}</td>
                  <td>${rowValues.lastname}</td>
                  <td>${rowValues.ci}</td>
                  <td>${rowValues.tla}</td>
                  <td>${rowValues.platform}</td>
                  <td>${rowValues.managerEmployeeId}</td>
                  <td>${rowValues.environment}</td>
                  `
        tablebdy.append(newrow)
    }

    

$(document).ready( function () {
    $('#searchResTable').DataTable();
} );




	/*			
				
				
				for (var i = 0; i < tableValueLength; i++) 
    {
    	var row = tableBody.insertRow(i);
    	var rowValues = tableValue[i];
    	var rowValuesLength = rowValues.length;
    	
		//===== create Cells ====
		var cell1 = row.insertCell(0);
		var cell2 = row.insertCell(1);
		var cell3 = row.insertCell(2);
		var cell4 = row.insertCell(3);
		var cell5 = row.insertCell(4);
		var cell6 = row.insertCell(5);
		var cell7 = row.insertCell(6);
		var cell8 = row.insertCell(7);
		
		//var cell4 = row.insertCell(3);
		//console.log(rowValues.firstname);
		//console.log(rowValues.lastname);
		//console.log(rowValues.userId);
		
		//==== insert values in cells ===
		
		cell1.innerHTML = rowValues.userId;
		cell2.innerHTML = rowValues.firstname;
		cell3.innerHTML = rowValues.lastname;
		cell4.innerHTML = rowValues.ci;
		cell5.innerHTML = rowValues.tla;
		cell6.innerHTML = rowValues.platform;
		cell7.innerHTML = rowValues.managerEmployeeId;
		cell8.innerHTML = rowValues.environment;
		
		//cell4.innerHTML = rowValues[3];
    }
	*/			
	//new_fn_navigate_To_OtherPage('pagey',null,finalStringValue);
				
			}
		}
	}
}
